#include "raylib.h"
#include <stdio.h>

/*
    tema do workshop:
    "as coisas nao sao como parecem"
*/

typedef struct player {
    int x;
    int y;
    Vector2 hitboxPosition;
    Vector2 hitboxSize;
} Player;

typedef struct block {
    int x;
    int y;
    Vector2 hitboxPosition;
    Vector2 hitboxSize;
} Block;

int main(void)
{
    const int screenWidth = 700;
    const int screenHeight = 700;

    int Matriz[10][10]={0};
    Matriz[3][3] = 1;
    Matriz[3][4] = 1;

    InitWindow(screenWidth, screenHeight, "UFRGS");

    //inicializa��o da posicao do player
    Player hero;
    hero.x = screenWidth*.5;
    hero.y = screenHeight*.5;
    hero.hitboxPosition.x = hero.x;
    hero.hitboxPosition.y = hero.y;
    hero.hitboxSize.x = 32;
    hero.hitboxSize.y = 32;

    Rectangle rec_hero;
    rec_hero = (Rectangle){hero.x,hero.y,32,32};

    Block block;
    block.x = screenWidth*.7;
    block.y = screenHeight*.7;
    block.hitboxPosition = (Vector2){block.x,block.y};
    block.hitboxSize = (Vector2){32,32};

    Rectangle rec_block;
    rec_block = (Rectangle){block.x,block.y,70,70};

    Rectangle buff_up, buff_down, buff_left, buff_right;

    Texture2D player_texture = LoadTexture("assets/player_1.png");

    SetTargetFPS(60);

    int t=1;
    int speed = 2;
    bool coll_right, coll_left, coll_up, coll_down;

    while (!WindowShouldClose())
    {
        for(int i=0; i<10; i++)
        {
            for(int j=0; j<10; j++)
            {
                if(Matriz[i][j] == 1)
                {
                    DrawRectangle(0+70*i, 0+70*j, 70, 70, YELLOW);
                    rec_block.x = 0+70*i;
                    rec_block.y = 0+70*j;
                    /*
                    buff_up.x = 0+70*i;
                    buff_up.y = 0+70*j;
                    buff_up.height = 1;
                    buff_up.width = 70;*/
                    DrawRectangleRec(rec_block,RED);
                }
                else if (Matriz[i][j] == 0)
                {
                    DrawRectangle(0+70*i, 0+70*j, 70, 70, WHITE);
                }

                DrawRectangleLines(0+70*i, 0+70*j, 70, 70, BLACK);

                coll_left = CheckCollisionRecs((Rectangle){rec_block.x-1,rec_block.y,rec_block.width,rec_block.height}, rec_hero);
                coll_right = CheckCollisionRecs((Rectangle){rec_block.x+1,rec_block.y,rec_block.width,rec_block.height}, rec_hero);
                coll_up = CheckCollisionRecs((Rectangle){rec_block.x,rec_block.y-1,rec_block.width,rec_block.height}, rec_hero);
                coll_down = CheckCollisionRecs((Rectangle){rec_block.x,rec_block.y+1,rec_block.width,rec_block.height}, rec_hero);
            }
        }

        if (IsKeyDown(KEY_RIGHT) && !coll_left)// && !CheckCollisionRecs(rec_block, rec_hero))
            hero.x += 1*speed;
        if (IsKeyDown(KEY_LEFT) && !coll_right)// && !CheckCollisionRecs(rec_block, rec_hero))
            hero.x -= 1*speed;
        if (IsKeyDown(KEY_UP) && !coll_up) //&& !CheckCollisionRecs(rec_block, rec_hero))
            hero.y -= 1*speed;
        if (IsKeyDown(KEY_DOWN) && !coll_down)// && !CheckCollisionRecs(rec_block, rec_hero))
            hero.y += 1*speed;

        hero.hitboxPosition = (Vector2){hero.x, hero.y};
        rec_hero = (Rectangle){hero.x,hero.y,33,33};

        BeginDrawing();

        ClearBackground(RAYWHITE);
        DrawRectangleV(block.hitboxPosition, block.hitboxSize, RED);
        DrawRectangleV(hero.hitboxPosition, hero.hitboxSize, SKYBLUE);

        DrawTexture(player_texture, hero.x, hero.y-16, WHITE);
        EndDrawing();
    }

    CloseWindow();
    return 0;
}
